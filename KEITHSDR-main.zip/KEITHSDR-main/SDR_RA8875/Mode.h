#ifndef _MODE_H_
#define _MODE_H_
//
//	 Mode.h
//
#include <Arduino.h>

void selectMode(uint8_t mndx);

#endif //_MODE_H_
