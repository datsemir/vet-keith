#ifndef _VFO_H_
#define _VFO_H_

// VFO.h
#include <Arduino.h>

void initVfo(void);
void SetFreq(uint32_t Freq);

#endif //_VFO_H_