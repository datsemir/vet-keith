#ifndef _TUNER_H_
#define _TUNER_H_
//
//  Tuner.h
//
#include <Arduino.h>

void selectFrequency(int32_t newFreq);

#endif // _TUNER_H_
