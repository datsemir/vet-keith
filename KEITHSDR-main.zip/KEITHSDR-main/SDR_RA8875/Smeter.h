#ifndef _SMETER_H_
#define _SMETER_H_
//
//	Smeter.h
//
//

float Peak(void);

#endif // _SMETER_H_

