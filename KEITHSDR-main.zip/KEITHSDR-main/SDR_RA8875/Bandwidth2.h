#ifndef _BANDWIDTH2_H_
#define _BANDWIDTH2_H_
//
//    Bandwidth2.h
//
#include <Arduino.h>

void selectBandwidth(uint8_t bndx);

#endif  // _BANDWIDTH2_H_
